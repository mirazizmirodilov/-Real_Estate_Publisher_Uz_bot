# Real Estate Publisher Bot

Telegram bot for a real-estate agent. Send photos + property text; the bot parses the listing with OpenAI (optional), builds a clean listing, then automatically publishes to a Telegram channel and Instagram when official Meta credentials are configured.

## Automatic flow
1. Send property photos to the bot.
2. Put the property information in the last photo caption or send it as text.
3. Bot waits a few seconds for the batch to finish.
4. AI extracts title, price, address, area, rooms, floor and phone.
5. Bot publishes to Telegram channel and Instagram.
6. Bot returns per-platform status.

## Setup
- Create bot with @BotFather.
- Add the bot as admin to the target Telegram channel with posting permission.
- Copy `.env.example` to `.env` and fill `BOT_TOKEN` and `CHANNEL_ID`.
- Optional: set `OPENAI_API_KEY` for automatic parsing.
- Optional Instagram: use an eligible Professional Instagram account and Meta Graph API credentials; set `META_ACCESS_TOKEN` and `IG_USER_ID`.
- Install: `python -m pip install -r requirements.txt`
- Run: `python -m app.main`

## Important
The project intentionally does not bypass platform restrictions. OLX Uzbekistan, BirBir, Egasi and Joymee are reported as unsupported until an official, permitted API/integration is available. Do not add browser automation to evade their rules.
